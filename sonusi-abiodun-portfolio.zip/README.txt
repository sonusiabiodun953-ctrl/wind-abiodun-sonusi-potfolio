Sonusi Abiodun — data analytics portfolio

This is the full website, not one file you paste into a box.
Photo, case-study PDFs, and pages are separate files inside this folder.

Open in VS Code
1. Unzip this file.
2. VS Code: File -> Open Folder, and choose the unzipped folder.
3. In the terminal:
   npm install
   npm run dev
4. The site opens in your browser from the local address the terminal prints.

Put it on your own Vercel
1. Create a free account at https://vercel.com
2. Put this folder on GitHub (new repository, upload the files).
3. Vercel: Add New -> Project -> import that repository.
4. Build command: npm run build
5. Deploy. Vercel gives you the public link.

Edit your details
- src/data/portfolio.ts  (name, email, phone, LinkedIn, education)
- src/components/site/   (page sections)
- public/portrait.jpg    (photo)
- public/case-studies/   (PDFs)
- public/work/           (dashboard images)
